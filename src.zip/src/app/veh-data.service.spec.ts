/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { VehDataService } from './veh-data.service';

describe('VehDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [VehDataService]
    });
  });

  it('should ...', inject([VehDataService], (service: VehDataService) => {
    expect(service).toBeTruthy();
  }));
});
